//popup.js

document.addEventListener("DOMContentLoaded", () => {
  try {
    initializeExtensionToggle();
    initializePomodoroTimer();
    initializeSettings();
    // console.log("All components initialized successfully");
  } catch (error) {
    console.error("Error during initialization:", error);
  }
});

function initializeExtensionToggle() {
  const toggle = document.getElementById("toggleExtension");

  // Load current toggle state
  chrome.storage.local.get("extensionEnabled", ({ extensionEnabled }) => {
    toggle.checked = extensionEnabled ?? true; // default ON
  });

  // Save the state when toggled
  toggle.addEventListener("change", () => {
    const isNowEnabled = toggle.checked;

    chrome.storage.local.set({ extensionEnabled: isNowEnabled }, () => {
      // Only reload if extension is being ENABLED and we're on Instagram
      if (isNowEnabled) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const currentTab = tabs[0];
          if (!currentTab) {
            console.warn("No active tab found.");
            return;
          }

          console.log("Extension enabled - checking tab:", currentTab.url);

          // Only reload if we're on Instagram
          if (
            currentTab.url &&
            currentTab.url.startsWith("https://www.instagram.com/")
          ) {
            console.log("Reloading Instagram tab to activate extension");
            chrome.tabs.reload(currentTab.id);
          } else {
            console.log(
              "Not on Instagram - extension will activate when you visit Instagram"
            );
          }
        });
      } else {
        // Extension disabled - no need to reload
        console.log("Extension disabled");
      }
    });
  });
}

// Settings Management
class TimerSettings {
  constructor() {
    this.defaultSettings = {
      workTime: 25,
      shortBreak: 5,
      longBreak: 15,
      longBreakInterval: 4,
    };
  }

  async getSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get("timerSettings", ({ timerSettings }) => {
        resolve({ ...this.defaultSettings, ...timerSettings });
      });
    });
  }

  async saveSettings(settings) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ timerSettings: settings }, resolve);
    });
  }
}

// Pomodoro Timer Functionality
class StudyBuddyTimer {
  constructor() {
    this.timeDisplay = document.getElementById("timeDisplay");
    this.phaseDisplay = document.getElementById("phaseDisplay");
    this.progressFill = document.getElementById("progressFill");
    this.startBtn = document.getElementById("startBtn");
    this.stopBtn = document.getElementById("stopBtn");
    this.resetBtn = document.getElementById("resetBtn");
    this.completedCount = document.getElementById("completedCount");
    this.statusText = document.getElementById("statusText");

    this.updateInterval = null;
    this.settings = new TimerSettings();
    this.lastState = null;
  }

  init() {
    // Add event listeners
    this.startBtn.addEventListener("click", () => this.startTimer());
    this.stopBtn.addEventListener("click", () => this.stopTimer());
    this.resetBtn.addEventListener("click", () => this.resetTimer());

    // Listen for timer completion messages from background script
    chrome.runtime.onMessage.addListener((message) => {
      if (message.action === "timerCompleted") {
        this.showCompletionAlert(message.data);
      }
    });

    // Update display immediately and repeatedly until we get valid data
    this.updateDisplay();

    // Try updating a few more times to handle any timing issues
    setTimeout(() => this.updateDisplay(), 100);
    setTimeout(() => this.updateDisplay(), 300);

    // Start regular updates
    this.startUpdating();
  }

  async startTimer() {
    try {
      await this.sendMessage({ action: "start" });
      this.updateDisplay();
    } catch (error) {
      console.error("Error starting timer:", error);
    }
  }

  async stopTimer() {
    try {
      await this.sendMessage({ action: "stop" });
      this.updateDisplay();
    } catch (error) {
      console.error("Error stopping timer:", error);
    }
  }

  async resetTimer() {
    try {
      await this.sendMessage({ action: "reset" });
      // Add a small delay to ensure settings are loaded
      setTimeout(() => {
        this.updateDisplay();
      }, 100);
    } catch (error) {
      console.error("Error resetting timer:", error);
    }
  }

  async sendMessage(message) {
    return new Promise((resolve, reject) => {
      console.log("Sending message:", message); // Debug log
      chrome.runtime.sendMessage(message, (response) => {
        console.log("Received response:", response); // Debug log
        if (chrome.runtime.lastError) {
          console.error("Runtime error:", chrome.runtime.lastError);
          reject(chrome.runtime.lastError);
        } else {
          resolve(response);
        }
      });
    });
  }

  async getState() {
    try {
      return await this.sendMessage({ action: "getState" });
    } catch (error) {
      console.error("Error getting state:", error);
      return null;
    }
  }

  async updateDisplay() {
    const state = await this.getState();
    if (!state) {
      // If we can't get state, show loading
      this.timeDisplay.textContent = "--:--";
      this.phaseDisplay.textContent = "Loading...";
      return;
    }

    // NO CALCULATION HERE - use the timeRemaining directly from background script
    const timeRemaining = state.timeRemaining;
    const totalTime = state.totalTime;

    // Update time display
    this.timeDisplay.textContent = this.formatTime(timeRemaining);

    // Update phase display
    const phaseNames = {
      work: "Work Time",
      break: "Short Break",
      longBreak: "Long Break",
    };

    this.phaseDisplay.textContent =
      phaseNames[state.currentPhase] || "Work Time";
    this.phaseDisplay.className = `phase ${state.currentPhase}`;

    // Update progress bar
    const progress = ((totalTime - timeRemaining) / totalTime) * 100;
    this.progressFill.style.width = `${Math.max(0, Math.min(100, progress))}%`;

    // Update completed count
    this.completedCount.textContent = state.completedPomodoros;

    // Update status
    this.statusText.textContent = state.isRunning ? "Running" : "Ready";

    // Update button states
    this.updateButtonStates(state.isRunning);
  }

  updateButtonStates(isRunning) {
    this.startBtn.disabled = isRunning;
    this.stopBtn.disabled = !isRunning;

    if (isRunning) {
      this.startBtn.textContent = "Running";
      this.startBtn.classList.add("disabled");
    } else {
      this.startBtn.textContent = "Start";
      this.startBtn.classList.remove("disabled");
    }
  }

  formatTime(milliseconds) {
    const totalSeconds = Math.ceil(milliseconds / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;

    return `${minutes.toString().padStart(2, "0")}:${seconds
      .toString()
      .padStart(2, "0")}`;
  }

  startUpdating() {
    // Update every second
    this.updateInterval = setInterval(() => {
      this.updateDisplay();
    }, 1000);
  }

  stopUpdating() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }

  showCompletionAlert(data) {
    const phaseNames = {
      work: "Work Session",
      break: "Short Break",
      longBreak: "Long Break",
    };

    const nextPhaseNames = {
      work: "Short Break",
      break: "Work Session",
      longBreak: "Work Session",
    };

    // Override for long break
    if (data.nextPhase === "longBreak") {
      nextPhaseNames.work = "Long Break";
    }

    const completedPhaseName = phaseNames[data.completedPhase] || "Session";
    const nextPhaseName = phaseNames[data.nextPhase] || "Session";

    const message = `🎉 ${completedPhaseName} Complete!\n\nTime to start your ${nextPhaseName.toLowerCase()}.\n\nPomodoros completed: ${
      data.completedPomodoros
    }`;

    // Show browser alert
    console.log("Timer completed");
    alert(message);

    // Optional: Play a beep sound using Web Audio API
    try {
      const audioContext = new (window.AudioContext ||
        window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(
        0.01,
        audioContext.currentTime + 1
      );

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 1);
    } catch (e) {
      console.log("Could not play completion sound:", e);
    }
  }
}

// Settings Functionality
function initializeSettings() {
  const settingsBtn = document.getElementById("settingsBtn");
  const settingsModal = document.getElementById("settingsModal");
  const closeBtn = document.getElementById("closeSettings");
  const saveBtn = document.getElementById("saveSettings");
  const workTimeInput = document.getElementById("workTime");
  const shortBreakInput = document.getElementById("shortBreak");
  const longBreakInput = document.getElementById("longBreak");
  const longBreakIntervalInput = document.getElementById("longBreakInterval");

  // Check if all required elements exist
  if (
    !settingsBtn ||
    !settingsModal ||
    !closeBtn ||
    !saveBtn ||
    !workTimeInput ||
    !shortBreakInput ||
    !longBreakInput ||
    !longBreakIntervalInput
  ) {
    console.error("Settings elements not found:", {
      settingsBtn: !!settingsBtn,
      settingsModal: !!settingsModal,
      closeBtn: !!closeBtn,
      saveBtn: !!saveBtn,
      workTimeInput: !!workTimeInput,
      shortBreakInput: !!shortBreakInput,
      longBreakInput: !!longBreakInput,
      longBreakIntervalInput: !!longBreakIntervalInput,
    });
    return;
  }

  const settings = new TimerSettings();

  // Load current settings
  async function loadSettings() {
    const currentSettings = await settings.getSettings();
    workTimeInput.value = currentSettings.workTime;
    shortBreakInput.value = currentSettings.shortBreak;
    longBreakInput.value = currentSettings.longBreak;
    longBreakIntervalInput.value = currentSettings.longBreakInterval;
  }

  // Show settings modal
  settingsBtn.addEventListener("click", () => {
    loadSettings();
    settingsModal.style.display = "block";
  });

  // Hide settings modal
  closeBtn.addEventListener("click", () => {
    settingsModal.style.display = "none";
  });

  // Click outside modal to close
  settingsModal.addEventListener("click", (e) => {
    if (e.target === settingsModal) {
      settingsModal.style.display = "none";
    }
  });

  // Save settings
  saveBtn.addEventListener("click", async () => {
    const workTime = parseInt(workTimeInput.value);
    const shortBreak = parseInt(shortBreakInput.value);
    const longBreak = parseInt(longBreakInput.value);
    const longBreakInterval = parseInt(longBreakIntervalInput.value);

    // Validate inputs
    if (
      workTime < 1 ||
      workTime > 60 ||
      shortBreak < 1 ||
      shortBreak > 30 ||
      longBreak < 1 ||
      longBreak > 60 ||
      longBreakInterval < 2 ||
      longBreakInterval > 10
    ) {
      alert(
        "Please enter valid values:\n- Work time: 1-60 minutes\n- Short break: 1-30 minutes\n- Long break: 1-60 minutes\n- Long break interval: 2-10 pomodoros"
      );
      return;
    }

    const newSettings = {
      workTime,
      shortBreak,
      longBreak,
      longBreakInterval,
    };

    try {
      await settings.saveSettings(newSettings);

      // Notify background script of settings change
      await sendMessage({
        action: "updateSettings",
        settings: newSettings,
      });

      settingsModal.style.display = "none";

      // Update the timer display if needed
      if (window.studyBuddyTimer) {
        window.studyBuddyTimer.updateDisplay();
      }
    } catch (error) {
      console.error("Error saving settings:", error);
      alert("Error saving settings. Please try again.");
    }
  });

  // Load settings on initialization
  loadSettings();
}

// Initialize Pomodoro Timer
function initializePomodoroTimer() {
  const timer = new StudyBuddyTimer();
  timer.init();

  // Store reference for cleanup
  window.studyBuddyTimer = timer;
}

// Helper function for sending messages
async function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(response);
      }
    });
  });
}

// Clean up when popup closes
window.addEventListener("beforeunload", () => {
  if (window.studyBuddyTimer) {
    window.studyBuddyTimer.stopUpdating();
  }
});
