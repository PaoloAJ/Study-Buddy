class PomodoroTimer {
  constructor() {
    this.isRunning = false;
    this.currentPhase = "work";
    this.timeRemaining = 0;
    this.completedPomodoros = 0;
    this.startTime = null;

    // default settings
    this.settings = {
      workTime: 25,
      shortBreak: 5,
      longBreak: 15,
      longBreakInterval: 4,
    };

    this.loadSettings();
    this.loadState();
    this.initializeTimer();
  }

  async loadState() {
    try {
      const result = await chrome.storage.local.get([
        "timerState",
        "isRunning",
        "currentPhase",
        "completedPomodoros",
        "startTime",
      ]);

      if (result.timerState) {
        this.isRunning = result.timerState.isRunning || false;
        this.currentPhase = result.timerState.currentPhase || "work";
        this.completedPomodoros = result.timerState.completedPomodoros || 0;
        this.startTime = result.timerState.startTime || null;
        // Restore persisted remaining time if available (when stopped)
        if (typeof result.timerState.timeRemaining === "number") {
          this.timeRemaining = result.timerState.timeRemaining;
        }

        // Do NOT mutate timeRemaining when running; we compute dynamic remaining in getState()
        // Ensure timeRemaining has a sensible base value
        if (
          !this.isRunning &&
          (this.timeRemaining === 0 || this.timeRemaining == null)
        ) {
          this.timeRemaining = this.getPhaseTime(this.currentPhase);
        }
      }
    } catch (error) {
      console.error("Error loading timer state:", error);
    }
  }

  async saveState() {
    try {
      const timerState = {
        isRunning: this.isRunning,
        currentPhase: this.currentPhase,
        completedPomodoros: this.completedPomodoros,
        startTime: this.startTime,
        // Persist the base remaining time; when running we compute dynamic remaining from this base
        timeRemaining: this.timeRemaining,
      };
      await chrome.storage.local.set({ timerState });
    } catch (error) {
      console.error("Error saving timer state:", error);
    }
  }

  async loadSettings() {
    try {
      const result = await chrome.storage.local.get("timerSettings");
      if (result.timerSettings) {
        this.settings = { ...this.settings, ...result.timerSettings };
      }
    } catch (error) {
      console.error("Error loading settings:", error);
    }
  }

  async updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    await chrome.storage.local.set({ timerSettings: this.settings });

    if (!this.isRunning) {
      this.timeRemaining = this.getPhaseTime(this.currentPhase);
    }
  }

  getPhaseTime(phase) {
    switch (phase) {
      case "work":
        return this.settings.workTime * 60 * 1000;
      case "break":
        return this.settings.shortBreak * 60 * 1000;
      case "longBreak":
        return this.settings.longBreak * 60 * 1000;
      default:
        return this.settings.workTime * 60 * 1000;
    }
  }

  initializeTimer() {
    if (this.timeRemaining === 0) {
      this.timeRemaining = this.getPhaseTime(this.currentPhase);
    }
  }

  async start() {
    if (this.isRunning) return;

    this.isRunning = true;
    this.startTime = Date.now();
    await this.saveState();

    // Create Chrome alarm instead of setInterval
    const alarmName = "pomodoroTimer";

    // Clear any existing alarm
    await chrome.alarms.clear(alarmName);

    // Create a recurring alarm that fires every minute to check timer status
    // This handles timers longer than Chrome's alarm delay limit (~24 minutes)
    await chrome.alarms.create(alarmName, {
      periodInMinutes: 1,
    });

    console.log(`Timer started - recurring alarm set to check every minute`);
  }

  async stop() {
    if (!this.isRunning) return;

    // Calculate remaining time
    const elapsed = Date.now() - this.startTime;
    this.timeRemaining = Math.max(0, this.timeRemaining - elapsed);

    this.isRunning = false;
    this.startTime = null;
    await this.saveState();

    // Clear the alarm
    await chrome.alarms.clear("pomodoroTimer");

    console.log("Timer stopped, remaining:", this.timeRemaining);
  }

  async reset() {
    await this.stop();
    this.currentPhase = "work";
    this.timeRemaining = this.getPhaseTime(this.currentPhase);
    this.completedPomodoros = 0;
    await this.saveState();

    console.log("Timer reset");
  }

  async complete() {
    await this.stop();
    this.showNotification();

    const completedPhase = this.currentPhase;

    if (this.currentPhase === "work") {
      this.completedPomodoros++;

      if (this.completedPomodoros % this.settings.longBreakInterval === 0) {
        this.currentPhase = "longBreak";
      } else {
        this.currentPhase = "break";
      }
    } else {
      this.currentPhase = "work";
    }

    this.timeRemaining = this.getPhaseTime(this.currentPhase);
    await this.saveState();

    // Send completion message to popup if it exists
    try {
      chrome.runtime
        .sendMessage({
          action: "timerCompleted",
          data: {
            completedPhase: completedPhase,
            nextPhase: this.currentPhase,
            completedPomodoros: this.completedPomodoros,
          },
        })
        .catch(() => {
          // nothing happens if popup is open
        });
    } catch (e) {
      // ignore
    }

    console.log(`Phase completed. New phase: ${this.currentPhase}`);
  }

  showNotification() {
    const phaseNames = {
      work: "Work Session",
      break: "Short Break",
      longBreak: "Long Break",
    };

    // Get the phase that just completed (BEFORE the transition)
    const completedPhaseName = phaseNames[this.currentPhase];

    // Determine what the NEXT phase will be (this logic needs to run BEFORE complete() changes currentPhase)
    let nextPhaseName;
    if (this.currentPhase === "work") {
      // completedPomodoros will be incremented in complete() AFTER this method
      const upcomingCompletedCount = this.completedPomodoros + 1;
      if (upcomingCompletedCount % this.settings.longBreakInterval === 0) {
        nextPhaseName = "Long Break";
      } else {
        nextPhaseName = "Short Break";
      }
    } else {
      nextPhaseName = "Work Session";
    }

    const title = `${completedPhaseName} Complete!`;
    const message = `Time for your ${nextPhaseName.toLowerCase()}`;

    chrome.notifications.create({
      type: "basic",
      iconUrl: "popup_icon.png",
      title: title,
      message: message,
      priority: 2,
    });

    try {
      chrome.tts.speak(`${title} ${message}`, {
        rate: 1.0,
        volume: 0.8,
      });
    } catch (error) {
      console.log("TTS not available:", error);
    }
  }

  getState() {
    // Calculate current remaining time if running - ONLY DONE HERE
    let currentTimeRemaining = this.timeRemaining;
    if (this.isRunning && this.startTime) {
      const elapsed = Date.now() - this.startTime;
      // When running, remaining time is base remaining minus elapsed
      currentTimeRemaining = Math.max(0, this.timeRemaining - elapsed);
    }

    return {
      isRunning: this.isRunning,
      currentPhase: this.currentPhase,
      timeRemaining: currentTimeRemaining, // This is the ACTUAL current time
      totalTime: this.getPhaseTime(this.currentPhase),
      completedPomodoros: this.completedPomodoros,
      startTime: this.startTime,
      settings: this.settings,
    };
  }
}

const pomodoroTimer = new PomodoroTimer();

// handles Chrome alarms (this persists across service worker restarts)
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "pomodoroTimer") {
    console.log("Pomodoro alarm triggered!");

    // checks to see if timer should legit complete
    const state = pomodoroTimer.getState();
    if (state.isRunning && state.timeRemaining <= 0) {
      console.log("Timer completed - calling complete()");
      await pomodoroTimer.complete();
    } else if (state.isRunning) {
      console.log(
        `Timer still running - ${Math.ceil(
          state.timeRemaining / 1000 / 60
        )} minutes remaining`
      );
    } else {
      console.log("Timer not running - clearing alarm");
      await chrome.alarms.clear("pomodoroTimer");
    }
  }
});

// message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // sender is a placeholder
  // console.log("Received message:", request);

  try {
    switch (request.action) {
      case "start":
        pomodoroTimer.start().then(() => {
          sendResponse({ success: true, state: pomodoroTimer.getState() });
        });
        break;

      case "stop":
        pomodoroTimer.stop().then(() => {
          sendResponse({ success: true, state: pomodoroTimer.getState() });
        });
        break;

      case "reset":
        pomodoroTimer.reset().then(() => {
          sendResponse({ success: true, state: pomodoroTimer.getState() });
        });
        break;

      case "getState":
        sendResponse(pomodoroTimer.getState());
        break;

      case "updateSettings":
        pomodoroTimer.updateSettings(request.settings).then(() => {
          sendResponse({ success: true, settings: pomodoroTimer.settings });
        });
        break;

      default:
        console.warn("Unknown action:", request.action);
        sendResponse({ success: false, error: "Unknown action" });
    }
  } catch (error) {
    console.error("Error handling message:", error);
    sendResponse({ success: false, error: error.message });
  }

  return true; // keeps message channel open for async response
});

// handle extension startup  (restore timer state_
chrome.runtime.onStartup.addListener(async () => {
  console.log("Extension started - checking for running timer");
  await pomodoroTimer.loadState();
});

// handles extension installation (preset)
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("Extension installed");
    chrome.storage.local.set({
      extensionEnabled: true,
      timerSettings: pomodoroTimer.settings,
    });
  }
});
